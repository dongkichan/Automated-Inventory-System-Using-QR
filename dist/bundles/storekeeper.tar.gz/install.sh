sudo dpkg -i storekeeper-alpha-0.5.deb
sudo chmod 755 /opt/StoreKeeper-alpha

